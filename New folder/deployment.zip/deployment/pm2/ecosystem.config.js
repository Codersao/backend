module.exports = {
  apps: [
    {
      name: 'autofinder',
      script: './autofinder_backend/server.js',
      env: {
        NODE_ENV: 'production',
      },
    },
  ],
};