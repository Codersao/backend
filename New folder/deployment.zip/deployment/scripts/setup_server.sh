#!/bin/bash
sudo apt update
sudo apt install -y nodejs npm mongodb
sudo npm install -g pm2
sudo systemctl start mongodb
sudo systemctl enable mongodb