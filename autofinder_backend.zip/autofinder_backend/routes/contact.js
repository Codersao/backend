const express = require('express');
const router = express.Router();
const Complaint = require('../models/complaint');
const authenticate = require('../middleware/authenticate');

router.post('/', authenticate, async (req, res) => {
  const { issueType, description } = req.body;
  const complaint = new Complaint({
    userId: req.user.id,
    issueType,
    description,
  });
  await complaint.save();
  res.status(200).json({ message: 'Complaint submitted' });
});

module.exports = router;