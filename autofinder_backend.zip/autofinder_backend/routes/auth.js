const express = require('express');
const router = express.Router();
const User = require('../models/user');
const jwt = require('jsonwebtoken');
const transporter = require('../config/email');

router.post('/send-otp', async (req, res) => {
  const { email } = req.body;
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  await User.updateOne(
    { email },
    { $set: { otp, otpExpires: new Date(Date.now() + 5 * 60 * 1000) } },
    { upsert: true }
  );
  await transporter.sendMail({
    to: email,
    subject: 'AutoFinder OTP',
    text: `Your OTP is ${otp}`,
  });
  res.status(200).json({ message: 'OTP sent' });
});

router.post('/verify-otp', async (req, res) => {
  const { email, otp } = req.body;
  const user = await User.findOne({ email, otp, otpExpires: { $gt: new Date() } });
  if (!user) return res.status(400).json({ message: 'Invalid or expired OTP' });

  const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
  await User.updateOne({ email }, { $unset: { otp: 1, otpExpires: 1 } });
  res.status(200).json({ token, user });
});

module.exports = router;