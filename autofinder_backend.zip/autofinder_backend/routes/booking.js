const express = require('express');
const router = express.Router();
const Booking = require('../models/booking');
const authenticate = require('../middleware/authenticate');

router.post('/', authenticate, async (req, res) => {
  const { pickup, destination, isPremium } = req.body;
  const booking = new Booking({
    userId: req.user.id,
    pickup,
    destination,
    isPremium,
  });
  await booking.save();
  res.status(200).json({ message: 'Booking created' });
});

module.exports = router;