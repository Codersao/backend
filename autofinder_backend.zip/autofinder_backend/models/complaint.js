const mongoose = require('mongoose');

const complaintSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  issueType: { type: String, enum: ['driver', 'bug', 'feedback'] },
  description: String,
  status: { type: String, enum: ['new', 'in_progress', 'resolved'], default: 'new' },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Complaint', complaintSchema);