const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  role: { type: String, enum: ['student', 'driver'], required: true },
  name: String,
  email: { type: String, unique: true, required: true },
  phone: String,
  department: String,
  year: String,
  dob: String,
  gender: String,
  profilePhoto: String,
  otp: String,
  otpExpires: Date,
});

module.exports = mongoose.model('User', userSchema);