const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const WebSocket = require('ws');
const http = require('http');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.json());

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const autoLocations = new Map();

wss.on('connection', (ws) => {
  ws.on('message', (message) => {
    const data = JSON.parse(message);
    if (data.type === 'location' && data.userId) {
      autoLocations.set(data.userId, { lat: data.lat, lng: data.lng });
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({ autos: Array.from(autoLocations.values()) }));
        }
      });
    }
  });
});

app.use('/api/auth', require('./routes/auth'));
app.use('/api/book', require('./routes/booking'));
app.use('/api/contact', require('./routes/contact'));

server.listen(3000, () => console.log('Server running on port 3000'));