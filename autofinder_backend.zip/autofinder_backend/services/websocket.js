const WebSocket = require('ws');

module.exports = (server) => {
  const wss = new WebSocket.Server({ server });
  const autoLocations = new Map();

  wss.on('connection', (ws) => {
    ws.on('message', (message) => {
      const data = JSON.parse(message);
      if (data.type === 'location' && data.userId) {
        autoLocations.set(data.userId, { lat: data.lat, lng: data.lng });
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ autos: Array.from(autoLocations.values()) }));
          }
        });
      }
    });
  });
};